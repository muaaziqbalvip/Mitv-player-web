/* ═══════════════════════════════════════════════
   MITV PLAYER — M3U PLAYLIST PARSER
   By: Muaaz Iqbal | Muslim Islam Project
═══════════════════════════════════════════════ */

const M3UParser = (() => {

  /* ── Parse raw M3U text → structured channel list ── */
  function parse(text) {
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    if (!lines[0]?.startsWith('#EXTM3U')) {
      throw new Error('Invalid M3U file — missing #EXTM3U header.');
    }

    const channels = [];
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];

      if (line.startsWith('#EXTINF')) {
        const meta   = parseExtInf(line);
        const urlLine = lines[i + 1] || '';

        if (urlLine && !urlLine.startsWith('#')) {
          channels.push({
            id:        'm3u_' + channels.length,
            name:      meta.name      || 'Unknown Channel',
            category:  meta.group     || 'General',
            quality:   detectQuality(meta.name, urlLine),
            logo:      meta.logo      || '',
            thumbnail: '',
            stream:    urlLine,
            isLive:    true,
            tvgId:     meta.tvgId     || '',
            tvgLang:   meta.tvgLang   || '',
          });
          i += 2;
          continue;
        }
      }
      i++;
    }

    return channels;
  }

  /* ── Parse a single #EXTINF line ── */
  function parseExtInf(line) {
    const attr = (key) => {
      const match = line.match(new RegExp(`${key}="([^"]*)"`, 'i'));
      return match ? match[1].trim() : '';
    };

    // Channel name is after the last comma
    const nameMatch = line.match(/,(.+)$/);
    const name = nameMatch ? nameMatch[1].trim() : '';

    return {
      name,
      tvgId:   attr('tvg-id'),
      tvgLang: attr('tvg-language') || attr('tvg-lang'),
      logo:    attr('tvg-logo'),
      group:   attr('group-title') || attr('group') || categoriseByName(name),
    };
  }

  /* ── Auto-categorise if group-title is empty ── */
  function categoriseByName(name) {
    const n = name.toLowerCase();
    if (/news|خبر|خبريات|akhbar/.test(n))                    return 'News';
    if (/sport|cricket|foot|كرة|لیگ/.test(n))                 return 'Sports';
    if (/quran|قرآن|islam|peace|huda|iqraa|مسجد|masjid/.test(n)) return 'Islamic';
    if (/movie|film|cinema|sinema|فلم/.test(n))               return 'Movies';
    if (/music|موسيقى|گانا|song/.test(n))                     return 'Music';
    if (/kids|cartoon|باچے|اطفال/.test(n))                    return 'Kids';
    if (/entertain|drama|serial/.test(n))                     return 'Entertainment';
    return 'General';
  }

  /* ── Detect quality from name/URL ── */
  function detectQuality(name, url) {
    const s = (name + url).toLowerCase();
    if (/4k|uhd|2160/.test(s))    return '4K';
    if (/fhd|1080/.test(s))       return 'FHD';
    if (/hd|720/.test(s))         return 'HD';
    if (/sd|480|360/.test(s))     return 'SD';
    return 'HD';
  }

  /* ── Group channels by category ── */
  function groupByCategory(channels) {
    const map = {};
    channels.forEach(ch => {
      const cat = ch.category;
      if (!map[cat]) map[cat] = [];
      map[cat].push(ch);
    });

    const iconMap = {
      'News':          'fa-globe',
      'Sports':        'fa-futbol',
      'Islamic':       'fa-mosque',
      'Movies':        'fa-film',
      'Music':         'fa-music',
      'Kids':          'fa-child',
      'Entertainment': 'fa-star',
      'General':       'fa-tv',
    };

    return Object.entries(map).map(([label, channels]) => ({
      id:       'cat_' + label.toLowerCase().replace(/\s+/g, '_'),
      label,
      icon:     iconMap[label] || 'fa-tv',
      channels,
    }));
  }

  /* ── Fetch M3U from URL (with CORS proxy fallback) ── */
  async function fetchFromUrl(url) {
    // Try direct first
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(12000) });
      if (r.ok) return await r.text();
    } catch (_) {}

    // CORS proxy fallback
    const proxies = [
      `https://corsproxy.io/?${encodeURIComponent(url)}`,
      `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
      `https://cors-anywhere.herokuapp.com/${url}`,
    ];

    for (const proxy of proxies) {
      try {
        const r = await fetch(proxy, { signal: AbortSignal.timeout(15000) });
        if (r.ok) {
          const text = await r.text();
          if (text.includes('#EXTM3U')) return text;
        }
      } catch (_) {}
    }

    throw new Error('Could not fetch playlist. Try downloading and uploading the file instead.');
  }

  /* ── Read file ── */
  function readFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = e => resolve(e.target.result);
      reader.onerror = () => reject(new Error('Failed to read file.'));
      reader.readAsText(file);
    });
  }

  return { parse, groupByCategory, fetchFromUrl, readFile };
})();
