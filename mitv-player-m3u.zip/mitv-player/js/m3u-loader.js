/* ═══════════════════════════════════════════════
   MITV PLAYER — M3U LOADER CONTROLLER
   By: Muaaz Iqbal | Muslim Islam Project
   (Injected before DOMContentLoaded fires)
═══════════════════════════════════════════════ */

const M3ULoader = (() => {

  const STORAGE_KEY = 'mitv_m3u_saved';

  // State
  let activeTab    = 'url';
  let selectedFile = null;
  let isLoading    = false;
  let parsedData   = null; // { categories, raw }

  // DOM refs (resolved on init)
  let modal, urlInput, clearUrlBtn, fileInput, dropZone,
      fileChosen, fileName, fileRemove,
      loadBtn, loadBtnText, skipBtn,
      progressWrap, progressBar, progressLabel,
      errorWrap, errorMsg,
      statsWrap, statChannels, statCategories, statLive,
      savedTab, savedName, savedMeta, savedLoad, savedClear,
      m3uNavBtn;

  /* ─────────────────────────────
     INIT
  ───────────────────────────── */
  function init() {
    modal         = document.getElementById('m3uModal');
    urlInput      = document.getElementById('m3uUrlInput');
    clearUrlBtn   = document.getElementById('m3uClearUrl');
    fileInput     = document.getElementById('m3uFileInput');
    dropZone      = document.getElementById('m3uDropZone');
    fileChosen    = document.getElementById('m3uFileChosen');
    fileName      = document.getElementById('m3uFileName');
    fileRemove    = document.getElementById('m3uFileRemove');
    loadBtn       = document.getElementById('m3uLoadBtn');
    loadBtnText   = document.getElementById('m3uLoadBtnText');
    skipBtn       = document.getElementById('m3uSkip');
    progressWrap  = document.getElementById('m3uProgress');
    progressBar   = document.getElementById('m3uProgressBar');
    progressLabel = document.getElementById('m3uProgressLabel');
    errorWrap     = document.getElementById('m3uError');
    errorMsg      = document.getElementById('m3uErrorMsg');
    statsWrap     = document.getElementById('m3uStats');
    statChannels  = document.getElementById('statChannels');
    statCategories= document.getElementById('statCategories');
    statLive      = document.getElementById('statLive');
    savedTab      = document.getElementById('savedTab');
    savedName     = document.getElementById('m3uSavedName');
    savedMeta     = document.getElementById('m3uSavedMeta');
    savedLoad     = document.getElementById('m3uSavedLoad');
    savedClear    = document.getElementById('m3uSavedClear');
    m3uNavBtn     = document.getElementById('m3uNavBtn');

    bindEvents();
    checkSaved();

    // Show on first load if no saved data
    const saved = getSaved();
    if (!saved) {
      openModal();
    } else {
      // Auto-load saved playlist silently
      applySavedPlaylist(saved);
      m3uNavBtn.classList.add('loaded');
    }
  }

  /* ─────────────────────────────
     EVENTS
  ───────────────────────────── */
  function bindEvents() {
    // Nav button
    m3uNavBtn.addEventListener('click', openModal);

    // Tabs
    document.querySelectorAll('.m3u-tab').forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    // URL clear
    clearUrlBtn.addEventListener('click', () => { urlInput.value = ''; urlInput.focus(); });

    // Load button
    loadBtn.addEventListener('click', handleLoad);

    // Skip button
    skipBtn.addEventListener('click', () => {
      closeModal();
      MITVApp.toast('Using demo channels', 'fa-tv');
    });

    // File input
    fileInput.addEventListener('change', e => {
      if (e.target.files[0]) setFile(e.target.files[0]);
    });

    // Drop zone
    dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
    dropZone.addEventListener('drop', e => {
      e.preventDefault();
      dropZone.classList.remove('drag-over');
      const f = e.dataTransfer.files[0];
      if (f) setFile(f);
    });

    // File remove
    fileRemove.addEventListener('click', clearFile);

    // Saved: load again
    savedLoad.addEventListener('click', () => {
      const saved = getSaved();
      if (saved) { applySavedPlaylist(saved); closeModal(); }
    });

    // Saved: clear
    savedClear.addEventListener('click', () => {
      localStorage.removeItem(STORAGE_KEY);
      savedTab.style.display = 'none';
      switchTab('url');
      MITVApp.toast('Saved playlist cleared', 'fa-trash');
      // Reset to demo
      MITVApp.loadDemoData();
      m3uNavBtn.classList.remove('loaded');
    });

    // Enter key on URL input
    urlInput.addEventListener('keydown', e => { if (e.key === 'Enter') handleLoad(); });

    // Paste anywhere when modal open
    document.addEventListener('paste', e => {
      if (!modal.classList.contains('open')) return;
      if (activeTab !== 'url') return;
      const text = e.clipboardData.getData('text');
      if (text.startsWith('http')) {
        urlInput.value = text;
        urlInput.dispatchEvent(new Event('input'));
      }
    });
  }

  /* ─────────────────────────────
     TABS
  ───────────────────────────── */
  function switchTab(tab) {
    activeTab = tab;
    document.querySelectorAll('.m3u-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    document.querySelectorAll('.m3u-tab-content').forEach(c => c.classList.toggle('active', c.id === `tab-${tab}`));
    hideError(); hideProgress(); statsWrap.style.display = 'none';
  }

  /* ─────────────────────────────
     FILE HANDLING
  ───────────────────────────── */
  function setFile(file) {
    selectedFile = file;
    fileName.textContent = file.name;
    fileChosen.style.display = 'flex';
    dropZone.style.display = 'none';
    switchTab('file');
  }
  function clearFile() {
    selectedFile = null;
    fileInput.value = '';
    fileChosen.style.display = 'none';
    dropZone.style.display = 'flex';
  }

  /* ─────────────────────────────
     LOAD HANDLER
  ───────────────────────────── */
  async function handleLoad() {
    if (isLoading) return;
    hideError(); statsWrap.style.display = 'none';

    let rawText = null;
    let sourceName = '';

    if (activeTab === 'url') {
      const url = urlInput.value.trim();
      if (!url) { showError('Please enter an M3U URL.'); return; }
      if (!url.startsWith('http')) { showError('URL must start with http:// or https://'); return; }
      sourceName = url;
      setLoading(true, 'Connecting to URL…');
      setProgress(15, 'Fetching playlist…');
      try {
        rawText = await M3UParser.fetchFromUrl(url);
      } catch (err) {
        setLoading(false);
        hideProgress();
        showError(err.message);
        return;
      }
      setProgress(60, 'Parsing channels…');

    } else if (activeTab === 'file') {
      if (!selectedFile) { showError('Please choose an M3U file.'); return; }
      sourceName = selectedFile.name;
      setLoading(true, 'Reading file…');
      setProgress(30, 'Reading file…');
      try {
        rawText = await M3UParser.readFile(selectedFile);
      } catch (err) {
        setLoading(false);
        hideProgress();
        showError(err.message);
        return;
      }
      setProgress(65, 'Parsing channels…');
    }

    // Parse
    let channels;
    try {
      channels = M3UParser.parse(rawText);
    } catch (err) {
      setLoading(false);
      hideProgress();
      showError(err.message);
      return;
    }

    if (channels.length === 0) {
      setLoading(false);
      hideProgress();
      showError('No valid channels found in this playlist.');
      return;
    }

    setProgress(90, `Found ${channels.length} channels…`);

    const categories = M3UParser.groupByCategory(channels);
    parsedData = { categories, channels, sourceName };

    setProgress(100, 'Done!');
    await sleep(400);
    hideProgress();
    setLoading(false);

    // Show stats
    showStats(channels, categories);

    // Save to localStorage (URL only, not file content — too big)
    if (activeTab === 'url') {
      save({ sourceName, channels: channels.length, categories: categories.length, timestamp: Date.now() });
      checkSaved();
    }

    // Apply to app
    setTimeout(() => {
      MITVApp.loadM3UData(categories);
      closeModal();
      m3uNavBtn.classList.add('loaded');
      MITVApp.toast(`✅ ${channels.length} channels loaded`, 'fa-check-circle');
    }, 800);
  }

  /* ─────────────────────────────
     SAVED PLAYLIST
  ───────────────────────────── */
  function save(meta) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(meta));
  }
  function getSaved() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch { return null; }
  }
  function checkSaved() {
    const saved = getSaved();
    if (saved) {
      savedTab.style.display = 'flex';
      savedName.textContent = saved.sourceName?.length > 45
        ? '…' + saved.sourceName.slice(-42)
        : (saved.sourceName || 'Unknown');
      savedMeta.textContent = `${saved.channels} channels · ${saved.categories} categories · ${timeAgo(saved.timestamp)}`;
    }
  }
  function applySavedPlaylist(saved) {
    // Just show info — actual data not re-fetched (would need to re-parse)
    m3uNavBtn.classList.add('loaded');
    m3uNavBtn.title = `Loaded: ${saved.sourceName}`;
  }

  /* ─────────────────────────────
     UI HELPERS
  ───────────────────────────── */
  function openModal() { modal.classList.add('open'); }
  function closeModal() { modal.classList.remove('open'); }

  function setLoading(state, btnText = 'Load Playlist') {
    isLoading = state;
    loadBtn.disabled = state;
    loadBtn.classList.toggle('loading', state);
    loadBtnText.textContent = state ? 'Loading…' : 'Load Playlist';
    if (state) loadBtn.innerHTML = `<i class="fas fa-spinner"></i> <span>Loading…</span>`;
    else        loadBtn.innerHTML = `<i class="fas fa-play"></i> <span>Load Playlist</span>`;
  }

  function setProgress(pct, label) {
    progressWrap.style.display = 'block';
    progressBar.style.width = pct + '%';
    progressLabel.textContent = label;
  }
  function hideProgress() { progressWrap.style.display = 'none'; progressBar.style.width = '0'; }

  function showError(msg) {
    errorMsg.textContent = msg;
    errorWrap.style.display = 'flex';
  }
  function hideError() { errorWrap.style.display = 'none'; }

  function showStats(channels, categories) {
    const liveCount = channels.filter(c => c.isLive).length;
    statChannels.textContent   = channels.length;
    statCategories.textContent = categories.length;
    statLive.textContent       = liveCount;
    statsWrap.style.display    = 'flex';
    // Animate numbers
    animateCount(statChannels, channels.length);
    animateCount(statCategories, categories.length);
    animateCount(statLive, liveCount);
  }

  function animateCount(el, target) {
    let start = 0;
    const step = Math.ceil(target / 30);
    const timer = setInterval(() => {
      start = Math.min(start + step, target);
      el.textContent = start;
      if (start >= target) clearInterval(timer);
    }, 30);
  }

  function timeAgo(ts) {
    const diff = Date.now() - ts;
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  return { init, openModal, closeModal };

})();
